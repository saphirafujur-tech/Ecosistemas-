# 🌍 Misión Ecosistema

Juego educativo gamificado para 1º ESO.

## Cómo usar
1. Abrir index.html
2. Subir a GitHub Pages

## Objetivo
Aprender ecosistemas jugando.
