let puntos=0;
let progreso=0;

function sumar(){
puntos+=1;
progreso+=10;
actualizar();
}

function validar(){
let r=document.getElementById("respuesta").value.toLowerCase();
if(r.includes("seres vivos")){
puntos+=5;
progreso+=30;
document.getElementById("mensaje").innerText="Correcto!";
}else{
document.getElementById("mensaje").innerText="Sigue intentando";
}
actualizar();
}

function actualizar(){
document.getElementById("puntos").innerText=puntos;
document.getElementById("barra").style.width=progreso+"%";
document.getElementById("barra").innerText=progreso+"%";
}
